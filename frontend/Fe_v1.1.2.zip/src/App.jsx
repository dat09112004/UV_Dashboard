import { AlertAssignmentLine, ProgressivePaginationBar } from './components/common/index.js';
import LanguageSwitch from './locales/LanguageSwitch.jsx';
import { localizeInvalidInput, clearLocalizedValidation, resetLocalizedValidation } from './locales/formValidation.js';
import { t, locale, getLanguage, subscribeLanguage, phrase, translate } from './locales/i18n.js';
import React, { lazy, Suspense, useState, useMemo, useEffect, useRef, useSyncExternalStore } from 'react';
import {
  Search, CheckCircle2, ChevronRight, Eye, X, Lock, ArrowRight, Flame,
  EyeOff, Maximize2, Minimize2, ArrowLeft, Download, RotateCcw, CalendarDays, AlertTriangle, ShieldCheck
} from 'lucide-react';

import { useDebouncedValue } from './hooks/useDebounce.js';
import { useRemotePage } from './hooks/useRemotePage.js';
import { fetchOrdersPage, fetchOrderCollection, fetchOrderHistory } from './features/orders/services/ordersService.js';
import { can, canOpenSection, homeSection, isExecutiveRole } from './utils/roles.js';
import { createEmptyDirectoryState, directoryProfiles, refreshDirectoryFromApi, saveDirectoryAction, taskWorkspace } from './features/users/services/directoryService.js';
import { canAssignTasks, isTaskEmployee, REMINDER_PENDING } from './features/operations/services/taskWorkflow.js';
import { saveEntryBatch } from './features/dataEntry/service.js';
import { clearEntryDrafts } from './features/dataEntry/drafts.js';
import { signIn, restoreSessionOnLoad } from './features/auth/services/authService.js';
import {
  abortAllPageRequests,
  clearAuthToken,
  executeFinanceActionApi,
  isFinanceSnapshotPayload,
  logoutApi,
  updateOrderProgressApi, fetchOrdersApi, fetchFinanceStateApi, fetchOrderDetailApi, fetchTermsPolicyApi,
  getStoredAuthSession,
  LOGOUT_BROADCAST_KEY,
  parseCrossTabLogoutPayload,
  SESSION_EXPIRED_EVENT,
} from './services/api.js';
import AppHeader, { NAV_ITEMS } from './components/layout/AppHeader.jsx';
import DashboardOverview, { OverviewKpis, AttentionSummary, EmployeeAlertReminder } from './components/dashboard/DashboardOverview.jsx';
import { CategoryProgressChart, RevenueChart, RevenueTaxProfitabilityPanel } from './components/dashboard/LazyCharts.jsx';
import { comparePriority, classifyDebt, classifyProgress, debtSummary, summarizeCategories, buildAlertQueue, debtMatchesFilter, matchesOrigin, monthlyRevenueSeries, formatDate } from './utils/dashboardMetrics.js';
import { exportExcel } from './utils/exportExcel.js';
import { dateInputValue, parseBusinessDate } from './utils/business.js';
import FulfillmentTable from './components/orders/FulfillmentTable.jsx';
import ItemDetailPanel from './components/orders/ItemDetailPanel.jsx';
import DebtStatusOverview from './components/finance/DebtStatusOverview.jsx';
import DebtDetailPanel from './components/finance/DebtDetailPanel.jsx';
import { getRoleLayout, presentAlert } from './utils/dashboardPresentation.js';
import { alertDestination, payableAction } from './utils/workspaceUi.js';
import { InvoiceForm, ReceivableCrudForm, PayableCrudForm, ReceiptWorkspace, PayableForm, SplitPayableForm, FinanceHistory } from './components/finance/FinanceForms.jsx';
import { initialFinanceState, unallocatedTotal, payableWorkflowStatus, itemFinancialSummary, businessToday, AP_REVIEW, AP_PENDING, AP_APPROVED, AP_RETURNED, AP_SPLIT_REQUIRED } from './utils/financeWorkflow.js';
import { setClientIdentity } from './utils/permissions.js';
import { loadTrackedItems, getFulfillment, formatPercent, matchesFulfillment } from './utils/orderFulfillment.js';
const AccountsPage = lazy(() => import('./features/users/components/AccountsPage.jsx'));
const DataEntryPage = lazy(() => import('./features/dataEntry/DataEntryPage.jsx'));
const TasksPage = lazy(() => import('./features/operations/components/TasksPage.jsx'));
const RemindersPage = lazy(() => import('./features/operations/components/RemindersPage.jsx'));
const BRAND_LOGO = '/logo.png';
const EMPTY_LIST = Object.freeze([]);
const LOCKED_ACCOUNT_MESSAGE = 'Tài khoản đã bị khóa. Vui lòng liên hệ quản trị viên để mở khóa.';
const TERMS_REQUIRED_MESSAGE = 'Vui lòng tích chọn đồng ý Chính sách bảo mật và Điều khoản sử dụng trước khi đăng nhập.';
const matchesSearch = (value, query) => typeof value === 'string' &&
  (value.toLowerCase().includes(query) || translate(value, 'en').toLowerCase().includes(query));
const createEmptyFinance = () => initialFinanceState([], [], [], businessToday());
const panelSection = panel => ({
  ITEM_DETAIL: 'orders', RECORD_REV: 'revenue',
  ALLOCATE_AR: 'receivables', CREATE_AR: 'receivables', EDIT_AR: 'receivables',
  CREATE_AP: 'payables', EDIT_AP: 'payables',
  SPLIT_AP: 'payables', SUBMIT_AP: 'payables', REVIEW_AP: 'payables', PAY_AP: 'payables',
})[panel.type] || panel.debtType;
const canOpenPanel = (user, panel) => canOpenSection(user, panelSection(panel)) &&
  (!['RECORD_REV', 'SPLIT_AP'].includes(panel.type) || canOpenSection(user, 'orders'));

const formatVnd = (val) => {
  if (val === null || val === undefined || val === '—') return '—';
  if (val === 0) return '0 VND';
  return new Intl.NumberFormat(locale()).format(val) + ' VND';
};

// ============================================================================
// MAIN APPLICATION COMPONENT
// ============================================================================
export default function App() {
  const language = useSyncExternalStore(subscribeLanguage, getLanguage, getLanguage);
  useEffect(() => {
    document.documentElement.lang = language;
    document.title = t('UYEN VU INTERNATIONAL • Hệ thống Điều hành PO, Tiến độ, Doanh thu & Công nợ');
    document.querySelectorAll('input, select, textarea').forEach(resetLocalizedValidation);
  }, [language]);

  // Authentication & Login State
  const initialStoredSession = useMemo(() => getStoredAuthSession(), []);
  const [isAuthenticated, setIsAuthenticated] = useState(() => Boolean(initialStoredSession?.hasSession || initialStoredSession?.token));
  const [loginEmail, setLoginEmail] = useState(() => { try { return localStorage.getItem('uv-remembered-email') || ''; } catch { return ''; } });
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [loginNotice, setLoginNotice] = useState('');
  const [isSigningIn, setIsSigningIn] = useState(false);
  const loginLockDialog = useRef(null);
  const termsPolicyDialog = useRef(null);
  const [policy, setPolicy] = useState(null);
  const [policyError, setPolicyError] = useState('');
  const [policyAttempt, setPolicyAttempt] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    setPolicyError('');
    fetchTermsPolicyApi(controller.signal).then(data => {
      if (!controller.signal.aborted) setPolicy(data);
    }).catch(error => {
      if (!controller.signal.aborted) setPolicyError(error.message);
    });
    return () => controller.abort();
  }, [policyAttempt]);
  const [forgotPasswordSent, setForgotPasswordSent] = useState(false);

  const [currentAccountId, setCurrentAccountId] = useState(() => initialStoredSession?.accountId || initialStoredSession?.account?.id || null);
  const [isRestoringSession, setIsRestoringSession] = useState(() => Boolean(initialStoredSession?.hasSession || initialStoredSession?.token));
  const [sessionRestoreAttempt, setSessionRestoreAttempt] = useState(0);
  const [sessionRestoreError, setSessionRestoreError] = useState('');
  const [directory, setDirectory] = useState(() => {
    const base = createEmptyDirectoryState();
    if (initialStoredSession?.account) {
      base.accounts = [initialStoredSession.account];
    }
    return base;
  });
  const accounts = useMemo(() => directoryProfiles(directory), [directory]);
  const currentUser = accounts.find(account => account.id === currentAccountId && account.status === 'active') || null;
  const currentRole = currentUser?.role;
  const canUpdateProgress = can(currentUser, 'orders.update') && canOpenSection(currentUser, 'orders');
  const showOrders = canOpenSection(currentUser, 'orders');
  const showRevenue = canOpenSection(currentUser, 'revenue');
  const showReceivables = canOpenSection(currentUser, 'receivables');
  const showPayables = canOpenSection(currentUser, 'payables');
  const showReminders = canOpenSection(currentUser, 'reminders');
  const canRemindBoss = showReminders && currentRole !== 'CEO';
  const canManageArCrud = showReceivables && (can(currentUser, 'receivables.allocate') || can(currentUser, 'revenue.create'));
  const canManageApCrud = showPayables && (can(currentUser, 'payables.submit') || can(currentUser, 'payables.approve'));
  const fullReport = showOrders && showRevenue && showReceivables && showPayables;
  const [selectedSection, setActiveSection] = useState('overview');
  const activeSection = canOpenSection(currentUser, selectedSection) ? selectedSection : homeSection(currentUser);
  const reviewingResubmissions = activeSection === 'assignment-reviews';
  const [alertTaskDraft, setAlertTaskDraft] = useState(null);
  const [reminderDraft, setReminderDraft] = useState(null);
  const [directoryBusy, setDirectoryBusy] = useState(false);
  const [directoryError, setDirectoryError] = useState('');
  const directorySaving = useRef(false);
  const entrySaving = useRef(false);

  const allDirectoryTasks = Array.isArray(directory?.tasks) ? directory.tasks : EMPTY_LIST;
  const allReminders = Array.isArray(directory?.reminders) ? directory.reminders : EMPTY_LIST;
  const pendingRemindersCount = useMemo(
    () => allReminders.filter(r => r.status === REMINDER_PENDING).length,
    [allReminders],
  );

  useEffect(() => {
    let active = true;
    if (!getStoredAuthSession()) {
      setIsRestoringSession(false);
      setSessionRestoreError('');
      return;
    }
    setIsRestoringSession(true);
    setSessionRestoreError('');
    restoreSessionOnLoad()
      .then(restored => {
        if (!active) return;
        if (restored.status === 'authenticated' && restored.account) {
          setSessionRestoreError('');
          setDirectoryError('');
          if (restored.directory) setDirectory(restored.directory);
          setCurrentAccountId(prevId => {
            if (prevId !== restored.account.id) setDataRevision(v => v + 1);
            return restored.account.id;
          });
          setActiveSection(restored.homeSection || homeSection(restored.account));
          setIsAuthenticated(true);
        } else if (restored.status === 'transient_error') {
          const msg = restored.message || 'Kết nối tạm thời gián đoạn khi khôi phục phiên. Vui lòng thử lại.';
          setSessionRestoreError(msg);
          setDirectoryError(msg);
        } else if (restored.status === 'expired' || restored.status === 'anonymous') {
          setSessionRestoreError('');
          setCurrentAccountId(null);
          setIsAuthenticated(false);
          if (restored.status === 'expired') {
            setLoginNotice('Phiên đăng nhập đã hết hạn theo thời gian bảo mật. Vui lòng đăng nhập lại.');
          }
        }
      })
      .catch(err => {
        if (!active) return;
        const msg = err?.message || 'Không thể kết nối máy chủ để khôi phục phiên đăng nhập.';
        setSessionRestoreError(msg);
        setDirectoryError(msg);
      })
      .finally(() => {
        if (active) setIsRestoringSession(false);
      });
    return () => {
      active = false;
    };
  }, [sessionRestoreAttempt]);

  useEffect(() => {
    setClientIdentity(currentUser);
    if (!isRestoringSession && currentAccountId && !currentUser && !sessionRestoreError) {
      setCurrentAccountId(null);
      setIsAuthenticated(false);
    }
  }, [currentUser, currentAccountId, isRestoringSession, sessionRestoreError]);

  const [orderView, setOrderView] = useState('fulfillment');
  const [orderFilter, setOrderFilter] = useState('all');
  const [reportDate, setReportDate] = useState(() => businessToday());
  const [debtFilter, setDebtFilter] = useState('all');
  const [payableWorkflowFilter, setPayableWorkflowFilter] = useState('all');
  const [isExporting, setIsExporting] = useState(false);
  const exportAbortRef = useRef(null);
  useEffect(() => () => exportAbortRef.current?.abort(), [isAuthenticated, currentAccountId]);

  // Filter States + Debounced Search & Filter States
  const [selectedCategory, setSelectedCategory] = useState('Tất cả ngành hàng');
  const [selectedOrigin, setSelectedOrigin] = useState('Tất cả xuất xứ');
  const [onlyMyRoleRedAlerts, setOnlyMyRoleRedAlerts] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const debouncedSearchQuery = useDebouncedValue(searchQuery, 250);
  const debouncedCategory = selectedCategory;
  const debouncedOrigin = selectedOrigin;
  const debouncedDebtFilter = debtFilter;
  const debouncedPayableWorkflowFilter = payableWorkflowFilter;
  const debouncedOrderFilter = orderFilter;

  // Dữ liệu nghiệp vụ được nạp khi mở phân hệ có quyền.
  const [vendorItems, setVendorItems] = useState([]);
  const [ordersHasMore, setOrdersHasMore] = useState(false);
  const [ordersNextCursor, setOrdersNextCursor] = useState(null);
  const [ordersIncomplete, setOrdersIncomplete] = useState(false);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [finance, setFinance] = useState(createEmptyFinance);
  const [financeLoaded, setFinanceLoaded] = useState(false);
  const [dataRevision, setDataRevision] = useState(0);
  const [dataError, setDataError] = useState('');
  const [ordersWarning, setOrdersWarning] = useState('');
  const [dataLoading, setDataLoading] = useState(false);
  const dataPanel = ['overview', 'orders', 'revenue', 'receivables', 'payables', 'data-entry', 'reminders'].includes(activeSection);
  const loadOrders = showOrders && dataPanel;
  const loadFinance = (showRevenue || showReceivables || showPayables) && dataPanel;

  // Mục 08 & QA12 Fix: Tách tải PO thành useEffect hoàn toàn độc lập với Finance;
  // nối tiếp trực tiếp từ cursor của trang đầu tiên (initialItems: firstPage.items, startCursor: firstPage.nextCursor)
  // nên 100 PO chỉ tốn 1 request và 1.001 PO chỉ tốn đúng 11 request (không tải lặp trang 1!).
  useEffect(() => {
    if (!isAuthenticated || !loadOrders) return;
    const controller = new AbortController();
    setOrdersLoading(true);
    setOrdersWarning('');
    setOrdersIncomplete(false);
    fetchOrdersPage({ view: 'reference', limit: 100 }, controller.signal)
      .then(async firstPage => {
        if (controller.signal.aborted) return;
        if (!firstPage.hasMore || firstPage.nextCursor === null) {
          setVendorItems(loadTrackedItems(firstPage.items));
          setOrdersHasMore(false);
          setOrdersNextCursor(null);
          setOrdersIncomplete(false);
          return;
        }
        setOrdersHasMore(true);
        setOrdersNextCursor(firstPage.nextCursor);
        const allItems = await fetchOrderCollection(controller.signal, {
          maxPages: 100,
          limit: 100,
          initialItems: firstPage.items,
          startCursor: firstPage.nextCursor,
        });
        if (controller.signal.aborted) return;
        setVendorItems(loadTrackedItems(allItems));
        setOrdersHasMore(false);
        setOrdersNextCursor(null);
        setOrdersIncomplete(false);
      })
      .catch(err => {
        if (controller.signal.aborted) return;
        if (Array.isArray(err?.partialItems) && err.partialItems.length > 0) {
          setVendorItems(loadTrackedItems(err.partialItems));
        }
        setOrdersNextCursor(err?.nextCursor ?? null);
        setOrdersIncomplete(true);
        setOrdersWarning(err.message || 'Chưa tải đủ toàn bộ danh sách PO.');
      })
      .finally(() => {
        if (!controller.signal.aborted) setOrdersLoading(false);
      });
    return () => controller.abort();
  }, [isAuthenticated, currentAccountId, loadOrders, dataRevision]);

  // Mục 08 Fix: Tách tải trạng thái tài chính (Finance) hoàn toàn độc lập với tiến trình tải PO
  useEffect(() => {
    if (!isAuthenticated || !loadFinance) return;
    const controller = new AbortController();
    setDataLoading(true);
    setDataError('');
    fetchFinanceStateApi({}, controller.signal)
      .then(state => {
        if (controller.signal.aborted) return;
        if (state && isFinanceSnapshotPayload(state)) {
          setFinance(state);
          setFinanceLoaded(true);
        }
      })
      .catch(error => {
        if (!controller.signal.aborted) setDataError(error.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setDataLoading(false);
      });
    return () => controller.abort();
  }, [isAuthenticated, currentAccountId, loadFinance, dataRevision]);

  useEffect(() => {
    if (!isAuthenticated) return;
    const expire = () => {
      clearEntryDrafts(currentAccountId);
      setIsAuthenticated(false);
      setCurrentAccountId(null);
      setDirectory(createEmptyDirectoryState());
      setDirectoryError('');
      setVendorItems([]);
      setFinance(createEmptyFinance());
      setFinanceLoaded(false);
      setWorkspaceDirty(false);
      setWorkspacePanel(null);
      setLoginNotice('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
    };
    const handleCrossTabLogout = event => {
      if (event.key !== LOGOUT_BROADCAST_KEY || !event.newValue) return;
      const payload = parseCrossTabLogoutPayload(event.newValue);
      if (payload?.accountId && currentAccountId && payload.accountId !== currentAccountId) return;
      exportAbortRef.current?.abort();
      orderDetailRequest.current?.abort();
      clearAuthToken();
      clearEntryDrafts(currentAccountId);
      setIsAuthenticated(false);
      setCurrentAccountId(null);
      setDirectory(createEmptyDirectoryState());
      setDirectoryError('');
      setVendorItems([]);
      setFinance(createEmptyFinance());
      setFinanceLoaded(false);
      setWorkspaceDirty(false);
      setWorkspacePanel(null);
      setLoginNotice(
        payload?.serverRevoked === false
          ? 'Phiên đăng nhập đã được đóng ở một tab khác (máy chủ chưa xác nhận thu hồi).'
          : 'Phiên đăng nhập đã được đăng xuất ở một tab khác.'
      );
    };
    window.addEventListener(SESSION_EXPIRED_EVENT, expire);
    window.addEventListener('storage', handleCrossTabLogout);
    return () => {
      window.removeEventListener(SESSION_EXPIRED_EVENT, expire);
      window.removeEventListener('storage', handleCrossTabLogout);
    };
  }, [isAuthenticated, currentAccountId]);
  const revenueRecords = Array.isArray(finance?.revenue) ? finance.revenue : EMPTY_LIST;
  const receivables = Array.isArray(finance?.receivables) ? finance.receivables : EMPTY_LIST;
  const payables = Array.isArray(finance?.payables) ? finance.payables : EMPTY_LIST;
  const unallocatedCash = Array.isArray(finance?.receipts) ? unallocatedTotal(finance) : 0;

  // Centered workspace dialog with optional full-screen mode.
  const [workspacePanel, setWorkspacePanel] = useState(null);
  const orderDetailRequest = useRef(null);
  const workspaceDebt = workspacePanel?.data?.id
    ? (workspacePanel.debtType === 'receivables' || ['ALLOCATE_AR', 'EDIT_AR'].includes(workspacePanel.type)
      ? receivables : payables).find(row => row.id === workspacePanel.data.id)
    : null;
  const needsDebtRecord = ['SPLIT_AP', 'SUBMIT_AP', 'REVIEW_AP', 'PAY_AP', 'EDIT_AR', 'EDIT_AP'].includes(workspacePanel?.type) ||
    (workspacePanel?.type === 'ALLOCATE_AR' && workspacePanel.data?.id);
  const [isFullScreenPanel, setIsFullScreenPanel] = useState(false);
  useEffect(() => {
    setWorkspacePanel(panel => panel && !canOpenPanel(currentUser, panel) ? null : panel);
  }, [currentUser]);
  const [workspaceDirty, setWorkspaceDirty] = useState(false);
  const [isSavingWorkspace, setIsSavingWorkspace] = useState(false);
  const workspaceSavingRef = useRef(false);
  const workspaceDirtyRef = useRef(false);
  workspaceDirtyRef.current = workspaceDirty;
  const [showDiscardDialog, setShowDiscardDialog] = useState(false);
  const [workspaceError, setWorkspaceError] = useState('');
  const openWorkspace = panel => {
    if (!canOpenPanel(currentUser, panel)) return;
    orderDetailRequest.current?.abort();
    setWorkspaceDirty(false); setWorkspaceError(''); setShowDiscardDialog(false); setWorkspacePanel(panel);
  };
  const requestCloseWorkspace = () => {
    if (workspaceSavingRef.current) return;
    if (workspaceDirtyRef.current) setShowDiscardDialog(true);
    else setWorkspacePanel(null);
  };
  const openWorkAlert = alert => {
    const panel = alertDestination(alert, currentRole, showOrders);
    if (panel.type === 'ITEM_DETAIL') void openItem(panel.data);
    else openWorkspace(panel);
  };
  const resetFilters = () => {
    setSelectedCategory('Tất cả ngành hàng'); setSelectedOrigin('Tất cả xuất xứ');
    setSearchQuery(''); setOnlyMyRoleRedAlerts(false); setDebtFilter('all'); setPayableWorkflowFilter('all'); setOrderFilter('all');
  };
  const activeFilters = [
    selectedCategory !== 'Tất cả ngành hàng' && { label: selectedCategory, clear: () => setSelectedCategory('Tất cả ngành hàng') },
    selectedOrigin !== 'Tất cả xuất xứ' && { label: selectedOrigin, clear: () => setSelectedOrigin('Tất cả xuất xứ') },
    searchQuery && { label: phrase('Tìm: §', searchQuery), clear: () => setSearchQuery('') },
    onlyMyRoleRedAlerts && { label: 'Chỉ báo động đỏ', clear: () => setOnlyMyRoleRedAlerts(false) },
  ].filter(Boolean);
  useEffect(() => { if (showDiscardDialog) document.querySelector('[role="alertdialog"] button')?.focus(); }, [showDiscardDialog]);
  useEffect(() => { if (workspaceError) document.querySelector('.workspace-error')?.focus(); }, [workspaceError]);

  useEffect(() => {
    if (!workspacePanel) { setIsFullScreenPanel(false); return; }
    const previousOverflow = document.body.style.overflow;
    const previousFocus = document.activeElement;
    document.body.style.overflow = 'hidden';
    const dialog = document.querySelector('[role="dialog"]');
    (dialog?.querySelector('input:not([type=hidden]):not(:disabled), textarea:not(:disabled), select:not(:disabled)') || dialog?.querySelector('button'))?.focus();
    const handleKey = event => {
      if (event.key === 'Escape') {
        event.preventDefault();
        if (workspaceSavingRef.current) return;
        if (document.querySelector('[role="alertdialog"]')) setShowDiscardDialog(false);
        else if (workspaceDirtyRef.current) setShowDiscardDialog(true);
        else setWorkspacePanel(null);
      }
      const activeDialog = document.querySelector('[role="alertdialog"]') || dialog;
      if (event.key !== 'Tab' || !activeDialog) return;
      const focusable = [...activeDialog.querySelectorAll('button, input, select, textarea, [tabindex="0"]')].filter(el => !el.disabled && el.getClientRects().length);
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (!activeDialog.contains(document.activeElement)) { event.preventDefault(); first?.focus(); return; }
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener('keydown', handleKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', handleKey);
      previousFocus?.focus();
    };
  }, [workspacePanel]);

  useEffect(() => {
    if (!workspaceDirty) return;
    const beforeUnload = event => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', beforeUnload);
    return () => window.removeEventListener('beforeunload', beforeUnload);
  }, [workspaceDirty]);

  // Toast
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);
  useEffect(() => () => clearTimeout(toastTimer.current), []);
  const showToast = (msg, type = 'info') => {
    clearTimeout(toastTimer.current);
    setToast({ msg, type });
    toastTimer.current = setTimeout(() => setToast(null), 6000);
  };

  const reloadDirectory = async () => {
    try {
      setDirectory(await refreshDirectoryFromApi());
      setDirectoryError('');
    } catch (error) {
      if (error.name !== 'AbortError' && error.status !== 401) {
        setDirectoryError('Đã lưu thay đổi nhưng chưa tải được danh sách mới.');
      }
    }
  };

  const handleDirectoryAction = async (action, payload, reportError) => {
    if (directorySaving.current || !currentUser) return false;
    directorySaving.current = true;
    setDirectoryBusy(true);
    try {
      await saveDirectoryAction(currentUser.id, action, payload);
      await reloadDirectory();
      setDataRevision(version => version + 1);
      showToast(
        action === 'create-reminder' ? 'Đã gửi nhắc việc đến CEO và Admin.' :
        action === 'quick-assign-reminder' ? 'Đã giao việc nhanh và cập nhật trạng thái cảnh báo đỏ.' :
        'Đã lưu thay đổi.'
      );
      return true;
    } catch (error) {
      // F02 & F03 Fix: Khi thao tác đã được ghi nhận trước đó (409 REQUEST_ALREADY_COMMITTED) hoặc trạng thái tài khoản đã đổi (409 ACCOUNT_STATUS_CONFLICT), tự động tải lại danh sách mới nhất
      if (error.status === 409 || error.code === 'REQUEST_ALREADY_COMMITTED' || error.code === 'ACCOUNT_STATUS_CONFLICT') {
        await reloadDirectory();
        setDataRevision(version => version + 1);
      }
      if (reportError) reportError(error.message);
      else showToast(error.message, 'error');
      return false;
    } finally {
      directorySaving.current = false;
      setDirectoryBusy(false);
    }
  };

  // Handle Login Submit (Enforces mandatory Terms & Privacy Policy Checkbox)
  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    if (isSigningIn || !policy?.version) return;
    setLoginError('');
    setLoginNotice('');
    // F08 Fix: Tuân thủ chính sách requiredOnLogin đồng bộ với cấu hình Backend
    if (policy?.requiredOnLogin !== false && !acceptedTerms) {
      setLoginError(TERMS_REQUIRED_MESSAGE);
      return;
    }
    setIsSigningIn(true);
    let result;
    try {
      result = await signIn(loginEmail, loginPassword, acceptedTerms, policy?.version, { requiredOnLogin: policy?.requiredOnLogin });
    } catch (err) {
      if (err?.code === 'TERMS_VERSION_MISMATCH') {
        setPolicy(null);
        setAcceptedTerms(false);
        setPolicyAttempt(attempt => attempt + 1);
      }
      setLoginError(err?.message || 'Không thể xác minh tài khoản trong trình duyệt này.');
      return;
    } finally {
      setIsSigningIn(false);
    }
    if (result.status === 'terms_required') {
      setLoginError(result.message || TERMS_REQUIRED_MESSAGE);
      return;
    }
    if (result.status === 'locked') {
      setLoginError(LOCKED_ACCOUNT_MESSAGE);
      setLoginPassword('');
      setShowPassword(false);
      setForgotPasswordSent(false);
      loginLockDialog.current?.showModal();
      return;
    }
    if (result.status !== 'authenticated') {
      setLoginError('Email hoặc mật khẩu không đúng.');
      return;
    }
    const matched = result.account;
    try {
      if (rememberMe) localStorage.setItem('uv-remembered-email', matched.email);
      else localStorage.removeItem('uv-remembered-email');
    } catch { /* Storage may be unavailable in private browsing. */ }
    if (result.directory) setDirectory(result.directory);
    setCurrentAccountId(matched.id);
    setDataRevision(version => version + 1);
    setActiveSection(result.homeSection || homeSection(matched));
    setLoginError('');
    setIsAuthenticated(true);
    setLoginPassword('');
    setForgotPasswordSent(false);
    showToast(`Đăng nhập thành công với vai trò: ${matched.title}`, 'info');
  };

  const classifiedItems = useMemo(() => showOrders ? vendorItems.map(row => classifyProgress(row, reportDate)) : [], [showOrders, vendorItems, reportDate]);
  const classifiedAr = useMemo(() => showReceivables ? receivables.map(row => classifyDebt(row, reportDate)) : [], [showReceivables, receivables, reportDate]);
  const classifiedAp = useMemo(() => showPayables ? payables.map(row => classifyDebt(row, reportDate)) : [], [showPayables, payables, reportDate]);

  const sortedVendorItems = useMemo(() => classifiedItems.filter(item => {
    const q = debouncedSearchQuery.trim().toLowerCase();
    return (debouncedCategory === 'Tất cả ngành hàng' || item.category === debouncedCategory) &&
      matchesOrigin(item, debouncedOrigin, vendorItems) &&
      (!onlyMyRoleRedAlerts || item.priorityRank === 0) &&
      (!q || [item.poId, item.vendorNo, item.vendorName, item.vendorItemNo, item.category].some(value => matchesSearch(value, q)));
  }).sort(comparePriority),
  [classifiedItems, debouncedCategory, debouncedOrigin, vendorItems, onlyMyRoleRedAlerts, debouncedSearchQuery]);

  const sortedRevenueRecords = useMemo(() => (showRevenue ? revenueRecords : []).filter(row => {
    const q = debouncedSearchQuery.trim().toLowerCase();
    return (debouncedCategory === 'Tất cả ngành hàng' || row.category === debouncedCategory) &&
      matchesOrigin(row, debouncedOrigin, vendorItems) && (!onlyMyRoleRedAlerts || row.priorityRank === 0) &&
      (!q || [row.docNo, row.poId, row.sku, row.customerName, row.vendorName].some(value => matchesSearch(value, q)));
  }).sort((a, b) => a.priorityRank - b.priorityRank),
  [showRevenue, revenueRecords, debouncedCategory, debouncedOrigin, vendorItems, onlyMyRoleRedAlerts, debouncedSearchQuery]);

  const sortedReceivables = useMemo(() => classifiedAr.filter(row => {
    const q = debouncedSearchQuery.trim().toLowerCase();
    return (debouncedCategory === 'Tất cả ngành hàng' || row.category === debouncedCategory) &&
      matchesOrigin(row, debouncedOrigin, vendorItems) && (!onlyMyRoleRedAlerts || row.priorityRank === 0) &&
      (!q || [row.docNo, row.poId, row.sku, row.customerName, row.vendorRef].some(value => matchesSearch(value, q)));
  }).sort(comparePriority),
  [classifiedAr, debouncedCategory, debouncedOrigin, vendorItems, onlyMyRoleRedAlerts, debouncedSearchQuery]);

  const sortedPayables = useMemo(() => classifiedAp.filter(row => {
    const q = debouncedSearchQuery.trim().toLowerCase();
    return (debouncedCategory === 'Tất cả ngành hàng' || row.category === debouncedCategory) &&
      matchesOrigin(row, debouncedOrigin, vendorItems) && (!onlyMyRoleRedAlerts || row.priorityRank === 0) &&
      (!q || [row.docNo, row.poId, row.sku, row.supplierName, row.vendorNo].some(value => matchesSearch(value, q)));
  }).sort(comparePriority),
  [classifiedAp, debouncedCategory, debouncedOrigin, vendorItems, onlyMyRoleRedAlerts, debouncedSearchQuery]);

  const orderCategories = useMemo(() => [...new Set([...classifiedItems, ...classifiedAr, ...classifiedAp,
    ...(showRevenue ? revenueRecords : [])].map(row => row.category).filter(Boolean))],
  [classifiedItems, classifiedAr, classifiedAp, showRevenue, revenueRecords]);
  const categoryStats = useMemo(() => summarizeCategories(sortedVendorItems, sortedRevenueRecords, classifiedAr, orderCategories),
    [sortedVendorItems, sortedRevenueRecords, classifiedAr, orderCategories]);
  const visibleFinanceHistory = (Array.isArray(finance?.audit) ? finance.audit : []).filter(row => row?.type?.startsWith('INVOICE') ? showRevenue :
    (row?.type?.startsWith('RECEIPT') || row?.type?.startsWith('RECEIVABLE')) ? showReceivables : row?.type?.startsWith('PAYABLE') && showPayables);
  const arSummary = useMemo(() => debtSummary(sortedReceivables), [sortedReceivables]);
  const apSummary = useMemo(() => debtSummary(sortedPayables), [sortedPayables]);
  const alerts = useMemo(() => buildAlertQueue(sortedVendorItems, sortedReceivables, sortedPayables, { includeWarnings: true }), [sortedVendorItems, sortedReceivables, sortedPayables]);
  const tableReceivables = sortedReceivables.filter(row => activeSection !== 'receivables' || debtMatchesFilter(row, debouncedDebtFilter));
  const payableScope = sortedPayables.filter(row => debouncedPayableWorkflowFilter === 'all' || payableWorkflowStatus(row) === debouncedPayableWorkflowFilter);
  const tablePayables = activeSection === 'payables' ? payableScope.filter(row => debtMatchesFilter(row, debouncedDebtFilter)) : sortedPayables;
  const monthlyData = useMemo(() => monthlyRevenueSeries(sortedRevenueRecords), [sortedRevenueRecords]);

  const pageFilters = {
    reportDate,
    category: debouncedCategory === 'Tất cả ngành hàng' ? '' : debouncedCategory,
    origin: debouncedOrigin === 'Tất cả xuất xứ' ? '' : debouncedOrigin,
    search: debouncedSearchQuery.trim(),
    red: onlyMyRoleRedAlerts ? 'true' : '',
  };
  const productionPagination = useRemotePage(fetchOrdersApi, pageFilters,
    isAuthenticated && activeSection === 'orders' && orderView === 'production', dataRevision, 10, currentAccountId);
  const revenuePagination = useRemotePage(fetchFinanceStateApi, {
    ...pageFilters, section: 'revenue', compact: true,
  }, isAuthenticated && activeSection === 'revenue', dataRevision, 10, currentAccountId);
  const arPagination = useRemotePage(fetchFinanceStateApi, {
    ...pageFilters, section: 'receivables', compact: true, filter: debouncedDebtFilter,
  }, isAuthenticated && activeSection === 'receivables', dataRevision, 10, currentAccountId);
  const apPagination = useRemotePage(fetchFinanceStateApi, {
    ...pageFilters, section: 'payables', compact: true,
    filter: debouncedDebtFilter, workflow: debouncedPayableWorkflowFilter,
  }, isAuthenticated && activeSection === 'payables', dataRevision, 10, currentAccountId);

  const onNavigate = (section, filter = 'all', query) => {
    if (entrySaving.current) {
      showToast('Đang lưu dữ liệu. Vui lòng chờ.');
      return;
    }
    if (!canOpenSection(currentUser, section)) return;
    setAlertTaskDraft(null);
    setActiveSection(section);
    if (section === 'orders') {
      setOrderView(filter === 'production' ? 'production' : 'fulfillment');
      setOrderFilter(['production', 'red'].includes(filter) ? 'all' : filter);
    }
    setDebtFilter(['receivables', 'payables'].includes(section) ? filter : 'all');
    if (query !== undefined) setSearchQuery(query);
    if (filter === 'red' && section === 'orders') setOnlyMyRoleRedAlerts(true);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };
  const assignWorkAlert = alert => {
    if (!canAssignAlert || alert.data.priorityRank !== 0) return;
    const view = presentAlert(alert, currentRole);
    onNavigate('assignments');
    setAlertTaskDraft({
      sourceAlert: { type: alert.type, id: alert.id, reference: alert.reference },
      title: phrase('Xử lý báo động đỏ §', alert.reference).slice(0, 160),
      description: [t(view.subject), t(view.issue), t(view.action)].join('\n').slice(0, 1000),
    });
  };
  const remindWorkAlert = alert => {
    if (!alert || !canRemindBoss) return;
    const view = presentAlert(alert, currentRole);
    setWorkspacePanel(null);
    setReminderDraft({
      alertId: alert.id,
      alertType: alert.type || 'orders',
      reference: alert.reference,
      subject: view.subject || alert.label || alert.reference,
      issue: view.issue || alert.status || 'Báo động đỏ cần xử lý',
      message: `Cảnh báo đỏ ${alert.reference} (${view.issue || alert.status}) đã cảnh báo nhưng chưa thấy xử lý xong. Nhờ CEO / Admin kiểm tra và giao việc cho bộ phận phụ trách.`,
    });
    setActiveSection('reminders');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };
  const canAssignAlert = canAssignTasks(currentUser) && canOpenSection(currentUser, 'assignments');
  const alertReminderType = getRoleLayout(currentRole).alertType;
  const reminderAlerts = useMemo(() => isTaskEmployee(currentUser)
    ? buildAlertQueue(classifiedItems, classifiedAr, classifiedAp).filter(alert =>
      alertReminderType === 'finance' ? alert.type !== 'orders' : alert.type === alertReminderType)
    : [], [currentUser, alertReminderType, classifiedItems, classifiedAr, classifiedAp]);
  const showEmployeeReminders = showReminders && (activeSection === 'overview' ||
    (alertReminderType === 'orders' && activeSection === 'orders') ||
    (alertReminderType === 'finance' && ['receivables', 'payables'].includes(activeSection)));
  useEffect(() => () => orderDetailRequest.current?.abort(), [activeSection, isAuthenticated, reportDate]);
  const openItem = async item => {
    orderDetailRequest.current?.abort();
    const controller = new AbortController();
    orderDetailRequest.current = controller;
    try {
      const detail = await fetchOrderDetailApi(item.rowId, controller.signal);
      if (!controller.signal.aborted) {
        orderDetailRequest.current = null;
        openWorkspace({ type: 'ITEM_DETAIL', data: classifyProgress(detail, reportDate) });
      }
    } catch (error) {
      if (!controller.signal.aborted) showToast(error.message, 'error');
    }
  };
  const handleExport = async () => {
    if (isExporting || !fullReport) return;
    // Mục 07 Fix: Chặn xuất báo cáo khi danh sách PO đang tải dở
    if (showOrders && ordersLoading) {
      showToast('Đang tải danh sách đơn hàng PO, vui lòng đợi hoàn tất trước khi xuất báo cáo.', 'error');
      return;
    }
    exportAbortRef.current?.abort();
    const exportController = new AbortController();
    exportAbortRef.current = exportController;
    setIsExporting(true);
    try {
      // X01 & X02 Fix: Chụp snapshot toàn bộ dữ liệu và bộ lọc tại thời điểm bấm xuất Excel,
      // áp dụng đúng bộ lọc orderFilter khi đang ở phân hệ Đơn hàng, và chỉ lấy đúng phiếu thu/nguồn chứng từ tách gắn trực tiếp với chứng từ sau lọc
      const snapshotReportDate = reportDate;
      const snapshotSection = activeSection;
      const snapshotCategory = debouncedCategory;
      const snapshotOrigin = debouncedOrigin;
      const snapshotSearch = debouncedSearchQuery;
      const snapshotRedOnly = onlyMyRoleRedAlerts;
      const snapshotDebtFilter = debouncedDebtFilter;
      const snapshotWorkflowFilter = debouncedPayableWorkflowFilter;
      const snapshotOrderView = orderView;
      const snapshotOrderFilter = debouncedOrderFilter;
      const snapshotLanguage = language;

      let baseExportItems = sortedVendorItems;
      if (showOrders && (ordersHasMore || ordersIncomplete)) {
        try {
          const allRaw = await fetchOrderCollection(exportController.signal, {
            maxPages: 100,
            limit: 100,
            ...(ordersNextCursor !== null && vendorItems.length > 0
              ? { initialItems: vendorItems, startCursor: ordersNextCursor }
              : {}),
          });
          const trackedAll = loadTrackedItems(allRaw);
          setVendorItems(trackedAll);
          setOrdersHasMore(false);
          setOrdersNextCursor(null);
          setOrdersIncomplete(false);
          setOrdersWarning('');
          const allClassified = trackedAll.map(row => classifyProgress(row, snapshotReportDate));
          baseExportItems = allClassified.filter(item => {
            const q = snapshotSearch.trim().toLowerCase();
            return (
              (snapshotCategory === 'Tất cả ngành hàng' || item.category === snapshotCategory) &&
              matchesOrigin(item, snapshotOrigin, trackedAll) &&
              (!snapshotRedOnly || item.priorityRank === 0) &&
              (!q || [item.poId, item.vendorNo, item.vendorName, item.vendorItemNo, item.category].some(val => matchesSearch(val, q)))
            );
          }).sort(comparePriority);
        } catch (err) {
          setOrdersIncomplete(true);
          setOrdersWarning(err.message || 'Chưa tải đủ toàn bộ danh sách PO để xuất báo cáo.');
          showToast(
            err.message || 'Không thể xuất báo cáo vì danh sách PO chưa được tải đầy đủ. Vui lòng thử lại.',
            'error'
          );
          return;
        }
      }
      const exportVendorItems =
        snapshotSection === 'orders' && snapshotOrderView === 'fulfillment' && snapshotOrderFilter !== 'all'
          ? baseExportItems.filter(item => matchesFulfillment(item, snapshotOrderFilter, snapshotReportDate))
          : baseExportItems;

      const exportRevenue = sortedRevenueRecords;
      const exportReceivables = tableReceivables;
      const exportPayables = tablePayables;

      const orderHistory = showOrders && exportVendorItems.length > 0 ? await fetchOrderHistory(exportVendorItems, exportController.signal) : [];
      const hasDocumentFilter =
        snapshotCategory !== 'Tất cả ngành hàng' ||
        snapshotOrigin !== 'Tất cả xuất xứ' ||
        Boolean(snapshotSearch.trim()) ||
        snapshotRedOnly ||
        (snapshotSection === 'orders' && snapshotOrderView === 'fulfillment' && snapshotOrderFilter !== 'all') ||
        (['receivables', 'payables'].includes(snapshotSection) && snapshotDebtFilter !== 'all') ||
        (snapshotSection === 'payables' && snapshotWorkflowFilter !== 'all');

      const arDocNos = new Set(exportReceivables.map(r => r.docNo).filter(Boolean));
      const arIds = new Set(exportReceivables.map(r => r.id).filter(Boolean));
      const revDocNos = new Set(exportRevenue.map(r => r.docNo).filter(Boolean));
      const apDocNos = new Set(exportPayables.map(r => r.docNo).filter(Boolean));
      const apIds = new Set(exportPayables.map(r => r.id).filter(Boolean));
      const splitSourceIds = new Set(exportPayables.map(r => r.splitSourceId).filter(Boolean));
      const splitSourceDocNos = new Set(
        exportPayables.map(r => r.splitSourceDocNo || r.splitFrom).filter(Boolean)
      );

      const filteredAllocations = hasDocumentFilter
        ? (finance.allocations || []).filter(al => arIds.has(al.debtId) || arDocNos.has(al.docNo))
        : (finance.allocations || []);
      const allocatedReceiptIds = new Set(filteredAllocations.map(al => al.receiptId).filter(Boolean));
      const filteredReceipts = hasDocumentFilter
        ? (finance.receipts || []).filter(rec => allocatedReceiptIds.has(rec.id))
        : (finance.receipts || []);
      const filteredReceiptRefs = new Set(filteredReceipts.map(rec => rec.reference).filter(Boolean));
      const filteredPayments = hasDocumentFilter
        ? (finance.payments || []).filter(pay => apIds.has(pay.payableId) || apDocNos.has(pay.docNo))
        : (finance.payments || []);
      const filteredPaymentRefs = new Set(filteredPayments.map(pay => pay.reference).filter(Boolean));
      const filteredSplitSources = hasDocumentFilter
        ? (finance.payableSplitSources || []).filter(src =>
            splitSourceIds.has(src.id) ||
            splitSourceDocNos.has(src.docNo) ||
            apDocNos.has(src.docNo) ||
            (Array.isArray(src.splitInto) && src.splitInto.some(doc => apDocNos.has(doc)))
          )
        : (finance.payableSplitSources || []);
      const filteredAudit = hasDocumentFilter
        ? visibleFinanceHistory.filter(entry =>
            revDocNos.has(entry.reference) ||
            arDocNos.has(entry.reference) ||
            apDocNos.has(entry.reference) ||
            splitSourceDocNos.has(entry.reference) ||
            filteredReceiptRefs.has(entry.reference) ||
            filteredPaymentRefs.has(entry.reference)
          )
        : visibleFinanceHistory;

      await exportExcel({ Tien_do: exportVendorItems, Doanh_thu: exportRevenue,
        Phai_thu: exportReceivables, Phai_tra: exportPayables,
        ...(filteredSplitSources.length ? { Nguon_chung_tu_tach: filteredSplitSources } : {}),
        Nhat_ky_tien_do: orderHistory,
        Thu_tien: filteredReceipts, Phan_bo_thu: filteredAllocations, Chi_tien: filteredPayments, Nhat_ky_tai_chinh: filteredAudit,
        Nhap_giao_hang: exportVendorItems.map(item => ({ poId: item.poId, itemName: item.vendorItemNo, category: item.category, unit: item.unit,
          unitPriceVnd: item.unitPriceVnd, totalValueVnd: item.totalValueVnd,
          orderedQty: item.orderedQty, receivedQty: item.nhap, deliveredQty: item.deliveredQty,
          receivedPct: getFulfillment(item, snapshotReportDate).receivedPct, deliveredPct: getFulfillment(item, snapshotReportDate).deliveredPct,
          expectedReceiptDate: item.expectedReceiptDate, expectedDeliveryDate: item.etaDate, actualDeliveryDate: item.actualDeliveryDate,
          fulfillmentStatus: getFulfillment(item, snapshotReportDate).label })) },
        {
          'Nguồn dữ liệu': 'PostgreSQL qua REST API',
          'Ngày theo dõi': formatDate(snapshotReportDate),
          'Ngành hàng': snapshotCategory,
          'Xuất xứ': snapshotOrigin,
          'Tìm kiếm': snapshotSearch || t('Tất cả'),
          'Chỉ báo động đỏ': snapshotRedOnly ? 'Có' : 'Không',
          'Sổ thu chi và nhật ký': hasDocumentFilter ? 'Đã lọc đồng bộ theo các chứng từ trong bộ lọc hiện tại' : 'Toàn bộ giao dịch tài chính trong phạm vi được cấp quyền',
          'Phân hệ': snapshotSection,
          'Chế độ xem đơn hàng': snapshotSection === 'orders' ? snapshotOrderView : 'all',
          'Bộ lọc đơn hàng': snapshotSection === 'orders' && snapshotOrderView === 'fulfillment' ? snapshotOrderFilter : 'all',
          'Nhóm công nợ': ['receivables', 'payables'].includes(snapshotSection) ? snapshotDebtFilter : 'all',
          'Trạng thái hồ sơ chi': snapshotSection === 'payables' ? snapshotWorkflowFilter : 'all',
        }, snapshotLanguage);
      showToast('Đã xuất báo cáo Excel.');
    } catch (err) {
      if (err?.name === 'AbortError') {
        showToast('Đã hủy thao tác xuất báo cáo Excel.', 'info');
      } else {
        showToast(err?.message || 'Không thể xuất báo cáo. Vui lòng thử lại.', 'error');
      }
    }
    finally { if (exportAbortRef.current === exportController) exportAbortRef.current = null; setIsExporting(false); }
  };

  const handleSaveEntry = async (sheetId, rows) => {
    entrySaving.current = true;
    try {
      const result = await saveEntryBatch(currentUser.id, sheetId, rows);
      if (!result.issues?.length) {
        setDataRevision(version => version + 1);
        if (sheetId === 'tasks') await reloadDirectory();
      }
      return result;
    } finally {
      entrySaving.current = false;
    }
  };

  // Update production and cumulative receipt/delivery quantities via Backend RESTful API.
  const handleUpdateItemProgress = async (e) => {
    e.preventDefault();
    if (!canUpdateProgress || workspacePanel?.type !== 'ITEM_DETAIL' || workspaceSavingRef.current) return;
    const values = Object.fromEntries(new FormData(e.currentTarget));
    workspaceSavingRef.current = true;
    setIsSavingWorkspace(true);
    try {
      const target = workspacePanel.data;
      const res = await updateOrderProgressApi(target.rowId, {
        ...values,
        reportDate,
        expectedTrackingVersion: target.trackingVersion ?? null,
      });
      let updated = res?.item?.poId ? res.item : res?.poId ? res : null;
      if (!updated) {
        const detail = await fetchOrderDetailApi(target.rowId).catch(() => null);
        updated = detail?.item?.poId ? detail.item : detail?.poId ? detail : null;
      }
      if (updated) {
        setVendorItems(prev => prev.map(row => row.rowId === updated.rowId ? updated : row));
        setWorkspacePanel({ type: 'ITEM_DETAIL', data: classifyProgress(updated, reportDate) });
      }
      setDataRevision(version => version + 1);
      setWorkspaceDirty(false); setWorkspaceError('');
      showToast(`Đã lưu cập nhật và lịch sử ${target.poId}`);
    } catch (error) {
      if (error.status === 409 || error.code === 'REQUEST_ALREADY_COMMITTED') {
        setDataRevision(version => version + 1);
      }
      setWorkspaceError(error.message);
    }
    finally { workspaceSavingRef.current = false; setIsSavingWorkspace(false); }
  };

  const handleFinanceAction = async (action, payload, close = true) => {
    if (workspaceSavingRef.current || !financeLoaded || dataLoading || dataError) return null;
    workspaceSavingRef.current = true;
    setIsSavingWorkspace(true);
    try {
      const apiRes = await executeFinanceActionApi(action, {
        ...payload,
        expectedRevision: finance.revision,
      });
      let next =
        apiRes?.finance && isFinanceSnapshotPayload(apiRes.finance)
          ? apiRes.finance
          : isFinanceSnapshotPayload(apiRes)
            ? apiRes
            : null;
      if (!next && (apiRes?.committed || apiRes?.dataRevision !== undefined)) {
        const reconciled = await fetchFinanceStateApi({});
        if (isFinanceSnapshotPayload(reconciled)) next = reconciled;
      }
      if (!next) throw new Error('Không nhận được trạng thái tài chính mới từ máy chủ.');
      setFinance(next);
      setDataRevision(version => version + 1);
      if (action === 'split' && payableWorkflowFilter === AP_SPLIT_REQUIRED) setPayableWorkflowFilter(AP_REVIEW);
      setWorkspaceDirty(false); setWorkspaceError('');
      if (close) setWorkspacePanel(null);
      showToast(
        action === 'invoice' ? 'Đã ghi nhận doanh thu và khoản phải thu tương ứng.' :
        action === 'create-receivable' ? 'Đã tạo mới khoản công nợ phải thu.' :
        action === 'update-receivable' ? 'Đã cập nhật khoản công nợ phải thu.' :
        action === 'delete-receivable' ? 'Đã xóa khoản công nợ phải thu.' :
        action === 'payable' || action === 'create-payable' ? 'Đã tạo mới khoản công nợ phải trả.' :
        action === 'update-payable' ? 'Đã cập nhật khoản công nợ phải trả.' :
        action === 'delete-payable' ? 'Đã xóa khoản công nợ phải trả.' :
        action === 'split' ? 'Đã lưu các chứng từ riêng. Có thể lập đề nghị chi cho từng chứng từ.' : 'Đã lưu giao dịch và lịch sử xử lý.'
      );
      return next;
    } catch (error) {
      if (error.code === 'FINANCE_REVISION_CONFLICT' || error.code === 'REQUEST_ALREADY_COMMITTED' || error.status === 409) {
        setDataRevision(version => version + 1);
      }
      setWorkspaceError(error.message || 'Không thể lưu giao dịch.');
      return null;
    }
    finally { workspaceSavingRef.current = false; setIsSavingWorkspace(false); }
  };

  const handleDeleteDebt = async (debtType, row) => {
    if (!row?.id || workspaceSavingRef.current) return;
    if (Number(row.allocatedPaid || 0) > 0) {
      showToast('Không thể xóa chứng từ đã phát sinh giao dịch thu/chi.', 'error');
      return;
    }
    const action = debtType === 'receivables' ? 'delete-receivable' : 'delete-payable';
    await handleFinanceAction(action, { id: row.id }, true);
  };

  const renderPriorityBadge = (level) => {
    if (level === 'Báo động đỏ') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold bg-rose-600 text-white">
          <Flame className="w-3 h-3" />{t(" Báo động đỏ")}</span>
      );
    }
    if (level === 'Cần xử lý') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-semibold bg-rose-50 text-rose-800 border border-rose-200">{t("Cần xử lý")}</span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">{t("Đúng hạn")}</span>
    );
  };

  // ============================================================================
  // RENDER LOGIN PAGE WHEN NOT AUTHENTICATED
  // ============================================================================
  const logout = (noticeOverride = '') => {
    if (entrySaving.current) {
      showToast('Đang lưu dữ liệu. Vui lòng chờ.');
      return;
    }
    const baseNotice = typeof noticeOverride === 'string' ? noticeOverride : '';
    exportAbortRef.current?.abort();
    abortAllPageRequests();
    orderDetailRequest.current?.abort();
    clearEntryDrafts(currentAccountId);
    setAlertTaskDraft(null);
    setReminderDraft(null);
    setPayableWorkflowFilter('all');
    setIsAuthenticated(false);
    setCurrentAccountId(null);
    setVendorItems([]);
    setFinance(createEmptyFinance());
    setFinanceLoaded(false);
    setWorkspaceDirty(false);
    setDirectory(createEmptyDirectoryState());
    setDirectoryError('');
    setSearchQuery('');
    setSelectedCategory('Tất cả ngành hàng');
    setSelectedOrigin('Tất cả xuất xứ');
    setOnlyMyRoleRedAlerts(false);
    setDebtFilter('all');
    setOrderFilter('all');
    setReportDate(businessToday());
    setLoginPassword('');
    setLoginError('');
    setSessionRestoreError('');
    setLoginNotice(baseNotice);
    setForgotPasswordSent(false);
    setWorkspacePanel(null);
    setActiveSection('overview');
    setToast(null);
    logoutApi().catch(() => {
      setLoginNotice(
        baseNotice
          ? `${baseNotice} (Đã đóng phiên trên trình duyệt, máy chủ chưa xác nhận thu hồi phiên.)`
          : 'Đã đóng phiên trên trình duyệt. Máy chủ chưa xác nhận thu hồi phiên.'
      );
    });
  };

  const handlePasswordChanged = () => {
    logout('Đã đổi mật khẩu. Vui lòng đăng nhập lại bằng mật khẩu mới.');
  };

  if (!isAuthenticated || !currentUser) {
    return (
      <div className="login-screen" onInvalidCapture={localizeInvalidInput} onInputCapture={clearLocalizedValidation} onChangeCapture={clearLocalizedValidation}>
        <header className="login-brand">
          <div className="brand-mark"><img src={BRAND_LOGO} alt="" /></div>
          <span>UYEN VU <span className="brand-secondary">INTERNATIONAL</span></span>
          <LanguageSwitch />
        </header>
        <main className="login-main">
          <section className="login-card" aria-labelledby="login-title">
            <div className="login-emblem"><Lock size={24} strokeWidth={1.6} /></div>
            <h1 id="login-title">{t("Đăng nhập")}</h1>
            <p className="login-caption">{t("Hệ thống quản lý điều hành")}</p>
            {loginError && <div className="login-message login-error" role="alert">{t(loginError)}</div>}
            {policyError && <div className="login-message login-error" role="alert">
              {t(policyError)} <button type="button" onClick={() => setPolicyAttempt(attempt => attempt + 1)}>{t('Thử lại')}</button>
            </div>}
            {sessionRestoreError && <div className="login-message login-error" role="alert">
              {t(sessionRestoreError)} <button type="button" onClick={() => setSessionRestoreAttempt(attempt => attempt + 1)}>{t('Thử lại')}</button>
            </div>}
            {loginNotice && <div className="login-message" role="status">{t(loginNotice)}</div>}
            {forgotPasswordSent && <div className="login-message" role="status">{t("Vui lòng liên hệ quản trị viên để cấp lại mật khẩu.")}</div>}
            <form onSubmit={handleLoginSubmit} className="login-form">
              <div>
                <label htmlFor="login-email">Email</label>
                <input id="login-email" name="email" type="email" required autoComplete="username"
                  value={loginEmail} onChange={e => { setLoginEmail(e.target.value); setLoginError(''); }}
                  placeholder={t("Nhập email công việc")} />
              </div>
              <div>
                <label htmlFor="login-password">{t("Mật khẩu")}</label>
                <div className="password-field">
                  <input id="login-password" name="password" type={showPassword ? 'text' : 'password'} required
                    autoComplete="current-password" value={loginPassword}
                    onChange={e => { setLoginPassword(e.target.value); setLoginError(''); }} placeholder={t("Nhập mật khẩu")} />
                  <button type="button" onClick={() => setShowPassword(!showPassword)}
                    aria-label={t(showPassword ? 'Ẩn mật khẩu' : 'Hiện mật khẩu')} aria-pressed={showPassword}>
                    {showPassword ? <EyeOff size={19} /> : <Eye size={19} />}
                  </button>
                </div>
              </div>
              <div className="login-options">
                <label className="remember-email"><input type="checkbox" checked={rememberMe}
                  onChange={e => setRememberMe(e.target.checked)} />{t("Ghi nhớ email")}</label>
                <button type="button" onClick={() => setForgotPasswordSent(true)}>{t("Quên mật khẩu?")}</button>
              </div>
              <div className="login-terms-box rounded-lg border border-slate-200 bg-slate-50/80 p-3 text-xs text-slate-700 space-y-1.5">
                <label htmlFor="login-accept-terms" className="flex items-start gap-2 cursor-pointer font-medium text-slate-800">
                  <input
                    id="login-accept-terms"
                    name="acceptedTerms"
                    type="checkbox"
                    checked={acceptedTerms}
                    disabled={!policy}
                    onChange={e => {
                      setAcceptedTerms(e.target.checked);
                      if (e.target.checked && loginError === TERMS_REQUIRED_MESSAGE) {
                        setLoginError('');
                      }
                    }}
                    className="mt-0.5 shrink-0"
                  />
                  <span>
                    {t("Tôi đã đọc và đồng ý với Chính sách bảo mật và Điều khoản sử dụng hệ thống")}
                    <span className="text-rose-600 font-bold" aria-hidden="true"> *</span>
                  </span>
                </label>
                <div className="pl-5">
                  <button
                    type="button"
                    disabled={!policy}
                    onClick={() => termsPolicyDialog.current?.showModal()}
                    className="text-sky-700 hover:text-sky-900 underline font-semibold cursor-pointer text-[11px]"
                  >
                    {t("Xem chi tiết Chính sách bảo mật & Điều khoản sử dụng")}
                  </button>
                </div>
              </div>
              <button type="submit" className="login-submit" disabled={isSigningIn || !policy}>{t(isSigningIn ? 'Đang đăng nhập…' : 'Đăng nhập')} <ArrowRight size={18} /></button>
            </form>
          </section>
        </main>
        <dialog className="account-confirm-dialog login-lock-dialog" ref={loginLockDialog}
          aria-labelledby="login-lock-title" aria-describedby="login-lock-description">
          <div className="login-lock-icon"><Lock size={24} aria-hidden="true" /></div>
          <h2 id="login-lock-title">{t('Tài khoản đã bị khóa')}</h2>
          <p id="login-lock-description">{t('Vui lòng liên hệ quản trị viên để mở khóa trước khi đăng nhập lại.')}</p>
          <form method="dialog" className="workflow-footer">
            <button type="submit" className="primary">{t('Đã hiểu')}</button>
          </form>
        </dialog>
        <dialog
          className="account-confirm-dialog terms-policy-dialog max-w-lg"
          ref={termsPolicyDialog}
          aria-labelledby="terms-policy-title"
        >
          <div className="flex items-center gap-2 text-slate-900 mb-2">
            <ShieldCheck size={22} className="text-sky-700 shrink-0" />
            <h2 id="terms-policy-title" className="m-0 text-base font-bold">
              {t('Chính sách bảo mật & Điều khoản sử dụng')}
            </h2>
          </div>
          <div className="text-xs text-slate-700 space-y-2.5 max-h-72 overflow-y-auto pr-1 leading-relaxed">
            {policy?.sections?.map(({ heading, body }) => <p key={heading}>
              <strong>{t(heading)}</strong><br />{t(body)}
            </p>)}
          </div>
          <div className="workflow-footer mt-4">
            <button type="button" onClick={() => termsPolicyDialog.current?.close()}>{t('Đóng')}</button>
            <button
              type="button"
              className="primary"
              onClick={() => {
                setAcceptedTerms(true);
                if (loginError === TERMS_REQUIRED_MESSAGE) setLoginError('');
                termsPolicyDialog.current?.close();
              }}
            >
              {t('Tôi đồng ý')}
            </button>
          </div>
        </dialog>
        <footer className="login-footer">© {new Date().getFullYear()} Uyen Vu International</footer>
      </div>
    );
  }

  // ============================================================================
  // RENDER AUTHENTICATED WORKSPACE
  // ============================================================================
  return (
    <div className="app-shell min-h-screen text-slate-800 font-sans antialiased flex flex-col" onInvalidCapture={localizeInvalidInput} onInputCapture={clearLocalizedValidation} onChangeCapture={clearLocalizedValidation}>
      {toast && (
        <div className={`app-toast fixed bottom-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-xl shadow-lg border ${
          toast.type === 'error' ? 'bg-rose-900 text-white border-rose-700' : 'bg-slate-900 text-white border-slate-700'
        }`}>
          {toast.type === 'error' ? <AlertTriangle className="w-4 h-4 text-rose-200 shrink-0" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
          <span className="text-xs sm:text-sm font-medium">{t(toast.msg)}</span>
          <button aria-label={t("Đóng thông báo")} onClick={() => setToast(null)} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
      <AppHeader
        language={language}
        activeSection={reviewingResubmissions ? 'assignments' : activeSection}
        onNavigate={onNavigate}
        user={currentUser}
        onLogout={logout}
        onPasswordChanged={handlePasswordChanged}
        pendingRemindersCount={pendingRemindersCount}
      />
      {directoryError && <p className="workspace-error" role="alert">{t(directoryError)}{' '}
        <button type="button" onClick={reloadDirectory}>{t('Tải lại danh sách')}</button>
      </p>}
      {dataPanel && dataLoading && <p className="management-note" role="status">{t('Đang tải dữ liệu…')}</p>}
      {dataPanel && dataError && <p className="workspace-error" role="alert">{t(dataError)}{' '}
        <button type="button" onClick={() => setDataRevision(version => version + 1)}>{t('Thử lại')}</button>
      </p>}
      {dataPanel && ordersWarning && <p className="workspace-error" role="alert">{t(ordersWarning)}{' '}
        <button type="button" onClick={() => setDataRevision(version => version + 1)}>{t('Thử lại')}</button>
      </p>}
      <Suspense fallback={<main className="dashboard-workspace"><p role="status">{t('Đang tải dữ liệu…')}</p></main>}>
      {activeSection === 'data-entry' ? <main className="dashboard-workspace entry-page">
        <DataEntryPage key={currentUser.id} actor={currentUser} data={{ items: vendorItems, finance, directory }} onSave={handleSaveEntry} />
      </main> : activeSection === 'reminders' ? <main className="dashboard-workspace management-workspace tasks-workspace">
        <RemindersPage
          reminders={allReminders}
          tasks={allDirectoryTasks}
          accounts={accounts}
          alerts={alerts}
          actor={currentUser}
          busy={directoryBusy}
          onAction={handleDirectoryAction}
          onOpenAlert={openWorkAlert}
          onAssignAlert={canAssignAlert ? assignWorkAlert : undefined}
          onNavigate={onNavigate}
          initialDraft={reminderDraft}
          onClearDraft={() => setReminderDraft(null)}
        />
      </main> : ['users', 'tasks', 'assignments', 'assignment-reviews'].includes(activeSection) ? <main className={`dashboard-workspace management-workspace${activeSection === 'users' ? '' : ' tasks-workspace'}`}>
        {activeSection === 'users' ? <>
          <div className="page-heading"><div><p className="page-eyebrow">UYEN VU INTERNATIONAL</p>
            <h1>{t('Quản lý tài khoản')}</h1></div></div>
          <AccountsPage accounts={accounts} departmentNavigation={directory.departmentNavigation} actor={currentUser} onAction={handleDirectoryAction} busy={directoryBusy} />
        </> :
          <><TasksPage key={activeSection} {...taskWorkspace(directory, currentUser)}
            accounts={accounts} actor={currentUser} managing={activeSection !== 'tasks'}
            reReviewOnly={reviewingResubmissions} alertDraft={alertTaskDraft} onClearAlertDraft={() => setAlertTaskDraft(null)}
            onNavigate={onNavigate} onAction={handleDirectoryAction} busy={directoryBusy} /></>}
      </main> : <main className={`dashboard-workspace${activeSection === 'revenue' ? ' revenue-workspace' : ''}`}>
        <div className="page-heading"><div><p className="page-eyebrow">UYEN VU INTERNATIONAL</p><h1>{t(activeSection === 'overview' ? 'Tổng quan điều hành' : NAV_ITEMS.find(item => item.id === activeSection)?.label)}</h1></div><div className="page-heading-actions"><label className="report-date">{t("Ngày theo dõi")}<span className="report-date-control"><span>{formatDate(reportDate)}</span><CalendarDays size={14} /><input lang={locale()} aria-label={t("Ngày theo dõi")} type="date" min={dateInputValue(finance.openingDate) || '2020-01-01'} value={reportDate} onChange={e => { if (parseBusinessDate(e.target.value) && e.target.value >= (dateInputValue(finance.openingDate) || '2020-01-01')) setReportDate(e.target.value); }} /></span></label>{fullReport && <button className="export-button" onClick={handleExport} disabled={isExporting}><Download size={16} />{t(isExporting ? 'Đang xuất…' : 'Xuất báo cáo')}</button>}</div></div>
        <p className="mt-2 text-xs text-slate-600">{t('Hệ thống Điều hành Uyen Vu International · Dữ liệu đồng bộ trực tiếp từ máy chủ PostgreSQL & Redis Cache.')}</p>
        
        <AttentionSummary
          activeSection={activeSection}
          alerts={alerts}
          role={currentRole}
          onNavigate={onNavigate}
          onOpenAlert={openWorkAlert}
          canNavigate={section => canOpenSection(currentUser, section)}
          onAssignAlert={canAssignAlert ? assignWorkAlert : undefined}
          onRemindAlert={canRemindBoss ? remindWorkAlert : undefined}
          tasks={allDirectoryTasks}
          accounts={accounts}
          reminders={allReminders}
        />
        {showEmployeeReminders && (
          <EmployeeAlertReminder
            alerts={reminderAlerts}
            role={currentRole}
            onOpen={openWorkAlert}
            onRemindAlert={canRemindBoss ? remindWorkAlert : undefined}
            tasks={allDirectoryTasks}
            accounts={accounts}
            reminders={allReminders}
          />
        )}
        <section className="dashboard-filters" aria-label={t("Bộ lọc dữ liệu")}>
          <label htmlFor="category-filter">{t("Ngành hàng")}<select id="category-filter" value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)}>
            <option value="Tất cả ngành hàng">{t("Tất cả ngành hàng")}</option>{orderCategories.map(category => <option key={category}>{category}</option>)}
          </select></label>
          <label htmlFor="origin-filter">{t("Xuất xứ")}<select id="origin-filter" value={selectedOrigin} onChange={e => setSelectedOrigin(e.target.value)}>
            <option value="Tất cả xuất xứ">{t("Tất cả xuất xứ")}</option>{[...new Set(classifiedItems.map(row => row.countryOfOrigin).filter(Boolean))].map(origin => <option key={origin}>{origin}</option>)}
          </select></label>
          <label htmlFor="workspace-search" className="filter-search">{t("Tìm kiếm")}<span><Search size={16} /><input id="workspace-search" type="search" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder={t(activeSection === 'orders' ? 'Tìm PO, mã hàng, nhà cung cấp…' : activeSection === 'receivables' ? 'Tìm hóa đơn, khách hàng…' : activeSection === 'payables' ? 'Tìm chứng từ, nhà cung cấp…' : 'PO, mã hàng, chứng từ, đối tác…')} /></span></label>
          <button className={onlyMyRoleRedAlerts ? 'red-filter active' : 'red-filter'} aria-pressed={onlyMyRoleRedAlerts} onClick={() => setOnlyMyRoleRedAlerts(!onlyMyRoleRedAlerts)}><Flame size={16} />{t("Báo động đỏ")}</button>
          <button className="reset-filters" title={t("Xóa bộ lọc")} aria-label={t("Xóa bộ lọc")} onClick={resetFilters}><RotateCcw size={17} /><span>{t("Xóa lọc")}</span></button>
        </section>

        {activeFilters.length > 0 && <div className="active-filters" aria-label={t("Bộ lọc đang áp dụng")}><span>{t("Đang lọc")}</span>{activeFilters.map(filter => <button key={filter.label} onClick={filter.clear} aria-label={phrase('Bỏ lọc §', t(filter.label))}>{t(filter.label)}<X size={13} /></button>)}</div>}
        <OverviewKpis role={currentRole} items={sortedVendorItems} revenue={sortedRevenueRecords} ar={arSummary} ap={apSummary} onNavigate={onNavigate} canNavigate={section => canOpenSection(currentUser, section)} />
        <div className="page-content" key={activeSection}>
        {['receivables', 'payables'].includes(activeSection) && <div className="debt-detail-filter"><span>{phrase('§ chứng từ', activeSection === 'receivables' ? arPagination.totalItems : apPagination.totalItems)}</span><label htmlFor="debt-status-filter">{t("Trạng thái")}<select id="debt-status-filter" value={debtFilter} onChange={e => setDebtFilter(e.target.value)}>
          <option value="all">{t("Tất cả công nợ")}</option><option value="due">{t("Đến hạn & quá hạn")}</option><option value="red">{t("Báo động đỏ")}</option><option value="today">{t("Đến hạn hôm nay")}</option><option value="overdue">{t("Quá hạn")}</option><option value="upcoming">{t("Chưa đến hạn")}</option><option value="near">{t("Sắp đến hạn (1–7 ngày)")}</option><option value="future">{t("Chưa tới hạn (>7 ngày)")}</option><option value="attention">{t("Cần xử lý")}</option><option value="unknown">{t("Chưa có hạn")}</option><option value="paid">{t("Đã tất toán")}</option>
        </select></label></div>}
        {activeSection === 'overview' && <DashboardOverview role={currentRole} items={sortedVendorItems} revenue={sortedRevenueRecords} categoryStats={categoryStats}
          reportDate={reportDate} ar={arSummary} ap={apSummary} alerts={alerts} monthlyData={monthlyData} onNavigate={onNavigate} onOpenItem={openItem} onResetFilters={resetFilters} onOpenAlert={openWorkAlert}
          onAssignAlert={canAssignAlert ? assignWorkAlert : undefined} onRemindAlert={canRemindBoss ? remindWorkAlert : undefined} tasks={allDirectoryTasks} accounts={accounts} reminders={allReminders} />}
        {activeSection === 'orders' && <div className="order-view-tabs" aria-label={t("Chế độ tiến độ đơn hàng")}><button aria-pressed={orderView === 'fulfillment'} onClick={() => setOrderView('fulfillment')}>{t("Nhập & giao hàng")}</button><button aria-pressed={orderView === 'production'} onClick={() => setOrderView('production')}>{t("Sản xuất & đóng gói")}</button></div>}
        {activeSection === 'orders' && orderView === 'fulfillment' && <FulfillmentTable onResetFilters={resetFilters} items={sortedVendorItems} reportDate={reportDate} onOpenItem={openItem} selectedFilter={debouncedOrderFilter} onFilterChange={setOrderFilter} tasks={allDirectoryTasks} accounts={accounts} reminders={allReminders} onRemindAlert={canRemindBoss ? remindWorkAlert : undefined} />}
        {activeSection === 'orders' && orderView === 'production' && (
          <section className="space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 mt-1">{t("Tiến độ mã hàng & ngành hàng")}</h2>
                </div>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
                <div className="lg:col-span-5 min-w-0">
                  <CategoryProgressChart stats={categoryStats} />

                </div>

                <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {categoryStats.map(cat => (
                    <button type="button" aria-pressed={selectedCategory === cat.category}
                      key={cat.category}
                      onClick={() => setSelectedCategory(selectedCategory === cat.category ? 'Tất cả ngành hàng' : cat.category)}
                      className={`text-left p-3.5 rounded-xl border transition cursor-pointer ${
                        selectedCategory === cat.category
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-slate-50/70 hover:bg-slate-100 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold truncate">{cat.category}</span>
                        {cat.redCount > 0 && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white shrink-0">
                            {cat.redCount}{t(" Đỏ")}</span>
                        )}
                      </div>
                      <div className="mt-2 space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="opacity-75">{t("Số dòng mã hàng:")}</span>
                          <strong>{cat.totalItems}{t(" mã")}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="opacity-75">{t("TB Sản xuất / Đóng gói:")}</span>
                          <strong>{formatPercent(cat.avgOnProcess)} / {formatPercent(cat.avgPackaging)}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="opacity-75">{t("Mã có hàng về:")}</span>
                          <strong>{cat.receivedItems} / {cat.totalItems}{t(" mã")}</strong>
                        </div>
                        <div className="flex justify-between pt-1 border-t border-slate-200/40">
                          <span className="opacity-75">{t("Doanh thu:")}</span>
                          <strong>{formatVnd(cat.revenue)}</strong>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold uppercase border-b border-slate-200 whitespace-nowrap">
                      <th className="py-3 px-3">{t("Ưu tiên")}</th>
                      <th className="py-3 px-2.5">{t("PO / Nhà cung cấp")}</th>
                      <th className="py-3 px-3">{t("Nhà cung cấp & Ngành hàng")}</th>
                      <th className="py-3 px-3">{t("Mã hàng")}</th>
                      <th className="py-3 px-2.5 text-center">{t("Ngày phát hành PO")}</th>
                      <th className="py-3 px-3">{t("Sản xuất (%)")}</th>
                      <th className="py-3 px-3">{t("Đóng gói (%)")}</th>
                      <th className="py-3 px-3 text-center">{t("Lịch xuất / giao (ETD / ETA)")}</th>
                      <th className="py-3 px-2.5 text-right">{t("Tồn đầu")}</th>
                      <th className="py-3 px-2.5 text-right">{t("Nhập")}</th>
                      <th className="py-3 px-2.5 text-right">{t("Bán")}</th>
                      <th className="py-3 px-2.5 text-center">{t("Tồn kho")}</th>
                      <th className="py-3 px-2.5">{t("Xuất xứ / Mùa hàng")}</th>
                      <th className="py-3 px-3 text-right">{t("Chi tiết")}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {!productionPagination.loading && !productionPagination.error && !productionPagination.totalItems && <tr><td colSpan={14} className="empty-table">{t("Không có mã hàng phù hợp")}</td></tr>}
                    {productionPagination.visibleItems.map((row) => {
                      const isRed = row.priorityRank === 0;
                      const alertObj = { id: `order-${row.rowId}`, type: 'orders', reference: row.poId, label: row.vendorItemNo, status: row.alertLabel, data: row };
                      return (
                        <tr
                          key={row.rowId}
                          onClick={() => openItem(row)}
                          className={`${
                            isRed ? 'business-data-row has-alert bg-white hover:bg-slate-50' : 'business-data-row bg-white hover:bg-slate-50'
                          } transition cursor-pointer`}
                        >
                          <td className="py-3 px-3 whitespace-nowrap">
                            {renderPriorityBadge(row.alertLevel)}
                          </td>
                          <td className="py-3 px-2.5 whitespace-nowrap">
                            <div className="font-bold text-slate-900">{row.poId}</div>
                            <div className="text-[11px] font-mono text-slate-500">{t("NCC:")} {row.vendorNo}</div>
                          </td>
                          <td className="py-3 px-3">
                            <div className="font-semibold text-slate-800">{t(row.vendorName)}</div>
                            <div className="text-[11px] text-slate-500">{row.category}</div>
                          </td>
                          <td className="py-3 px-3">
                            <div className="font-bold text-slate-900">{t(row.vendorItemNo)}</div>
                            {isRed && (
                              <AlertAssignmentLine
                                alertRef={{ id: alertObj.id, type: 'orders', reference: row.poId }}
                                tasks={allDirectoryTasks}
                                accounts={accounts}
                                reminders={allReminders}
                                canRemind={canRemindBoss}
                                onRemind={() => remindWorkAlert(alertObj)}
                                compact={true}
                              />
                            )}
                          </td>
                          <td className="py-3 px-2.5 text-center font-medium text-slate-700 whitespace-nowrap">
                            {row.releasedPoDate}
                          </td>
                          <td className="py-3 px-3 min-w-[110px]">
                            <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full bg-sky-700"
                                style={{ width: `${row.onProcessPct ?? 0}%` }}
                              />
                            </div>
                            <div className="text-[11px] font-semibold text-slate-600 mt-1">{formatPercent(row.onProcessPct)}</div>
                          </td>
                          <td className="py-3 px-3 min-w-[110px]">
                            <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full bg-teal-600"
                                style={{ width: `${row.packagingPct ?? 0}%` }}
                              />
                            </div>
                            <div className="text-[11px] font-semibold text-slate-600 mt-1">{formatPercent(row.packagingPct)}</div>
                          </td>
                          <td className="py-3 px-3 text-center whitespace-nowrap">
                            <div className="font-bold text-slate-800">
                              ETD: {row.shipDateEtd}
                            </div>
                            <div className="text-[11px] text-slate-500">ETA: {row.etaDate}</div>
                          </td>
                          <td className="py-3 px-2.5 text-right font-mono text-slate-700">
                            {row.tonDau ? row.tonDau.toLocaleString(locale()) : '-'}
                          </td>
                          <td className="py-3 px-2.5 text-right font-mono font-bold text-slate-800">
                            {row.nhap ? row.nhap.toLocaleString(locale()) : '-'}
                          </td>
                          <td className="py-3 px-2.5 text-right font-mono font-bold text-slate-800">
                            {row.ban ? row.ban.toLocaleString(locale()) : '-'}
                          </td>
                          <td className="py-3 px-2.5 text-center font-mono text-slate-500">
                            {row.nhap != null && row.deliveredQty != null
                              ? (Number(row.tonDau || 0) + row.nhap - row.deliveredQty).toLocaleString(locale()) : '—'}
                          </td>
                          <td className="py-3 px-2.5 whitespace-nowrap">
                            <div className="font-semibold text-slate-700">{row.countryOfOrigin || '—'}</div>
                            <div className="text-[10px] text-slate-500">{[row.seasonCode, t(row.seasonDesc)].filter(Boolean).join(' • ')}</div>
                          </td>
                          <td className="py-3 px-3 text-right whitespace-nowrap">
                            <button onClick={event => { event.stopPropagation(); openItem(row); }} aria-label={t(`Chi tiết ${row.poId}`)} className="row-detail-button">
                              <span>{t("Chi tiết")}</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <ProgressivePaginationBar pagination={productionPagination} itemUnit="mã hàng" />
            </div>
          </section>
        )}
        {activeSection === 'revenue' && (
          <section className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs space-y-6 revenue-section-card">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
              <div>
                <h2 className="text-xl font-bold text-slate-900 mt-1">{t("Doanh thu")}</h2>
              </div>
              <div className="flex items-center gap-2">
                {showOrders && can(currentUser, 'revenue.create') && <button
                  onClick={() => openWorkspace({ type: 'RECORD_REV', data: null })}
                  className="px-3.5 py-2 rounded-lg bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 cursor-pointer"
                >{t("+ Ghi nhận doanh thu")}</button>}
              </div>
            </div>

            <RevenueChart stats={categoryStats} monthlyData={monthlyData} />
            <RevenueTaxProfitabilityPanel revenueRecords={sortedRevenueRecords} items={sortedVendorItems} />
            <div className="space-y-3">
              <h3 className="text-base font-bold text-slate-900">{t("Chứng từ doanh thu")}</h3>
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full min-w-[760px] text-left border-collapse text-sm revenue-data-table" aria-label={t("Chứng từ doanh thu")}>
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold uppercase border-b border-slate-200">
                      <th className="py-3 px-3.5">{t("Mức độ")}</th>
                      <th className="py-3 px-3.5">{t("Chứng từ / Ngày")}</th>
                      <th className="py-3 px-3.5">{t("Khách hàng & Mã hàng")}</th>
                      <th className="py-3 px-3.5 text-right">{t("Doanh thu ghi nhận")}</th>
                      <th className="py-3 px-3.5 text-right">{t("Đã thực thu")}</th>
                      <th className="py-3 px-3.5">{t("Đánh giá Kế toán")}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {!revenuePagination.loading && !revenuePagination.error && !revenuePagination.totalItems && <tr><td colSpan={6} className="empty-table">{t("Không có chứng từ doanh thu phù hợp")}</td></tr>}
                    {revenuePagination.visibleItems.map(rev => {
                      const isRed = rev.priorityRank === 0;
                      const alertObj = { id: `receivables-${rev.id}`, type: 'receivables', reference: rev.docNo, label: rev.customerName, status: rev.alertLevel, data: rev };
                      return (
                        <tr key={rev.id} className={isRed ? 'business-data-row has-alert bg-white' : 'business-data-row bg-white'}>
                          <td className="py-3 px-3.5 whitespace-nowrap">{renderPriorityBadge(rev.alertLevel)}</td>
                          <td className="py-3 px-3.5 whitespace-nowrap">
                            <div className="font-bold text-slate-900 text-sm">{rev.docNo}</div>
                            <div className="text-xs text-slate-500">{rev.recordDate} • {rev.poId}</div>
                          </td>
                          <td className="py-3 px-3.5">
                            <div className="font-semibold text-slate-800 text-sm">{t(rev.customerName)}</div>
                            <div className="text-xs text-slate-500">{t(rev.sku)}</div>
                            {isRed && (
                              <AlertAssignmentLine
                                alertRef={{ id: alertObj.id, type: 'receivables', reference: rev.docNo }}
                                tasks={allDirectoryTasks}
                                accounts={accounts}
                                reminders={allReminders}
                                canRemind={canRemindBoss}
                                onRemind={() => remindWorkAlert(alertObj)}
                                compact={true}
                              />
                            )}
                          </td>
                          <td className="py-3 px-3.5 text-right font-mono font-bold text-slate-900 text-sm whitespace-nowrap">
                            {formatVnd(rev.netRevenue)}
                          </td>
                          <td className="py-3 px-3.5 text-right font-mono font-semibold text-slate-700 text-sm whitespace-nowrap">
                            {formatVnd(rev.cashCollected)}
                          </td>
                          <td className="py-3 px-3.5 text-xs text-slate-600 max-w-xs">
                            {t(rev.statusNote)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <ProgressivePaginationBar pagination={revenuePagination} itemUnit="chứng từ doanh thu" />
            </div>
          </section>
        )}
        {activeSection === 'receivables' && (
          <section className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
              <div>
                <h2 className="text-lg font-bold text-slate-900 mt-1">{t("Công nợ phải thu")}</h2>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-600">{t("Tiền thu chưa phân bổ giữ riêng: ")}<strong className="text-slate-900">{formatVnd(unallocatedCash)}</strong>
                </span>
                {canManageArCrud && <button
                  type="button"
                  onClick={() => openWorkspace({ type: 'CREATE_AR', debtType: 'receivables', data: null })}
                  className="row-detail-button text-xs font-semibold"
                >{t("+ Thêm phải thu")}</button>}
                {can(currentUser, 'receivables.allocate') && <button
                  onClick={() => openWorkspace({ type: 'ALLOCATE_AR', data: null })}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 cursor-pointer"
                >{t("Thu tiền & phân bổ")}</button>}
              </div>
            </div>

            <DebtStatusOverview rows={sortedReceivables} debtType="receivables" role={currentRole}
              filter={debouncedDebtFilter} onFilter={setDebtFilter} onOpen={openWorkspace}
              redOnly={onlyMyRoleRedAlerts} onClearRed={() => { setOnlyMyRoleRedAlerts(false); setDebtFilter('all'); }}
              tasks={allDirectoryTasks} accounts={accounts} reminders={allReminders} onRemindAlert={canRemindBoss ? remindWorkAlert : undefined} />
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-xs border-b border-slate-200">
                    <th className="py-3 px-4">{t("Mức độ ưu tiên")}</th>
                    <th className="py-3 px-4">{t("Hóa đơn / PO")}</th>
                    <th className="py-3 px-4">{t("Khách hàng / Nhà cung cấp")}</th>
                    <th className="py-3 px-4">{t("Mã hàng")}</th>
                    <th className="py-3 px-4 text-center">{t("Hạn thanh toán")}</th>
                    <th className="py-3 px-4 text-right">{t("Phải thu gốc")}</th>
                    <th className="py-3 px-4 text-right">{t("Đã phân bổ")}</th>
                    <th className="py-3 px-4 text-right">{t("Còn phải thu")}</th>
                    <th className="py-3 px-4">{t("Ghi chú / Cam kết")}</th><th className="sticky-action">{t("Thao tác")}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {!arPagination.loading && !arPagination.error && !arPagination.totalItems && <tr><td colSpan={10} className="empty-table">{t("Không có khoản phải thu phù hợp. ")}<button onClick={resetFilters}>{t("Xóa bộ lọc")}</button></td></tr>}
                  {arPagination.visibleItems.map(ar => {
                    const isRed = ar.priorityRank === 0;
                    const alertObj = { id: `receivables-${ar.id}`, type: 'receivables', reference: ar.docNo, label: ar.customerName, status: ar.alertLabel, data: ar };
                    return (
                      <tr key={ar.id} className={isRed ? 'business-data-row has-alert bg-white hover:bg-slate-50' : 'business-data-row bg-white hover:bg-slate-50'}>
                        <td className="py-3 px-4 whitespace-nowrap">
                          {renderPriorityBadge(ar.alertLevel)}
                          <div className="text-[11px] text-slate-500 mt-0.5">{t(ar.agingBucket)}</div>
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                          <div>{ar.docNo}</div>
                          <div className="text-xs text-slate-500">{ar.poId}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-800">{t(ar.customerName)}</div>
                          <div className="text-xs text-slate-500">{t(ar.vendorRef)}</div>
                          {isRed && (
                            <AlertAssignmentLine
                              alertRef={{ id: alertObj.id, type: 'receivables', reference: ar.docNo }}
                              tasks={allDirectoryTasks}
                              accounts={accounts}
                              reminders={allReminders}
                              canRemind={canRemindBoss}
                              onRemind={() => remindWorkAlert(alertObj)}
                              compact={true}
                            />
                          )}
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-800">
                          <div>{t(ar.sku)}</div>
                          <div className="text-xs text-slate-500">{ar.category}</div>
                        </td>
                        <td className="py-3 px-4 text-center whitespace-nowrap">
                          <div className="font-bold text-slate-800">{ar.dueDate}</div>
                          {ar.overdueDays > 0 && (
                            <span className="text-xs font-bold text-rose-600">{phrase('Quá hạn § ngày', ar.overdueDays)}</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right font-mono">{formatVnd(ar.originalAmount)}</td>
                        <td className="py-3 px-4 text-right font-mono text-slate-700 font-semibold">{formatVnd(ar.allocatedPaid)}</td>
                        <td className={`py-3 px-4 text-right font-mono font-bold ${isRed ? 'text-rose-700' : 'text-slate-900'}`}>{formatVnd(ar.remaining)}</td>
                        <td className="py-3 px-4 text-xs text-slate-600 max-w-xs">
                          {t(ar.commitmentNote || '—')}
                        </td><td className="sticky-action"><div className="row-actions">{canManageArCrud && <button type="button" className="row-detail-button" onClick={() => openWorkspace({ type: 'EDIT_AR', debtType: 'receivables', data: ar })}>{t("Sửa")}</button>}{canManageArCrud && Number(ar.allocatedPaid || 0) === 0 && <button type="button" className="row-detail-button" onClick={() => handleDeleteDebt('receivables', ar)}>{t("Xóa")}</button>}<button className="row-detail-button" onClick={() => openWorkspace({ type: 'DEBT_DETAIL', debtType: 'receivables', data: ar })}>{t("Chi tiết")}<ChevronRight size={15} /></button></div></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <ProgressivePaginationBar pagination={arPagination} itemUnit="khoản phải thu" />
          </section>
        )}
        {activeSection === 'payables' && (
          <section className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
              <div>
                <h2 className="text-lg font-bold text-slate-900 mt-1">{t("Công nợ phải trả")}</h2>
              </div>
              <div className="flex items-center gap-2">
                {canManageApCrud && <button
                  type="button"
                  onClick={() => openWorkspace({ type: 'CREATE_AP', debtType: 'payables', data: null })}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 cursor-pointer"
                >{t("+ Thêm phải trả")}</button>}
              </div>
            </div>

            <div className="workflow-filter-tabs" aria-label={t("Lọc quy trình chi")}>{[['all', 'Tất cả hồ sơ'], [AP_SPLIT_REQUIRED, AP_SPLIT_REQUIRED], [AP_PENDING, 'Chờ CEO duyệt'], [AP_APPROVED, 'Đã duyệt chi'], [AP_REVIEW, 'Cần lập đề nghị'], [AP_RETURNED, 'Cần bổ sung']].map(([value, label]) => <button key={value} aria-pressed={payableWorkflowFilter === value} onClick={() => { setPayableWorkflowFilter(value); if (debtFilter !== 'all') setDebtFilter('all'); }}>{t(label)}<span>{value === 'all' ? sortedPayables.length : sortedPayables.filter(row => payableWorkflowStatus(row) === value).length}</span></button>)}</div>
            <DebtStatusOverview rows={payableScope} debtType="payables" role={currentRole} canSplit={showOrders}
              filter={debouncedDebtFilter} onFilter={setDebtFilter} onOpen={openWorkspace}
              redOnly={onlyMyRoleRedAlerts} onClearRed={() => { setOnlyMyRoleRedAlerts(false); setDebtFilter('all'); }}
              tasks={allDirectoryTasks} accounts={accounts} reminders={allReminders} onRemindAlert={canRemindBoss ? remindWorkAlert : undefined} />
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-xs border-b border-slate-200">
                    <th className="py-3 px-4">{t("Mức độ ưu tiên")}</th>
                    <th className="py-3 px-4">{t("Chứng từ / Mã NCC")}</th>
                    <th className="py-3 px-4">{t("Nhà cung cấp")}</th>
                    <th className="py-3 px-4">{t("Mã hàng & PO")}</th>
                    <th className="py-3 px-4 text-center">{t("Hạn thanh toán")}</th>
                    <th className="py-3 px-4 text-right">{t("Đã trả")}</th>
                    <th className="py-3 px-4 text-right">{t("Còn phải trả")}</th>
                    <th className="py-3 px-4 text-center">{t("Trạng thái hồ sơ")}</th>
                    <th className="py-3 px-4 text-right sticky-action">{t("Thao tác (")}{t(currentUser.roleLabel)})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {!apPagination.loading && !apPagination.error && !apPagination.totalItems && <tr><td colSpan={9} className="empty-table">{t("Không có khoản phải trả phù hợp. ")}<button onClick={resetFilters}>{t("Xóa bộ lọc")}</button></td></tr>}
                  {apPagination.visibleItems.map(ap => {
                    const isRed = ap.priorityRank === 0;
                    const action = payableAction(ap, currentRole, showOrders);
                    const status = payableWorkflowStatus(ap);
                    const alertObj = { id: `payables-${ap.id}`, type: 'payables', reference: ap.docNo, label: ap.supplierName, status: ap.alertLabel, data: ap };
                    return (
                      <tr key={ap.id} className={isRed ? 'business-data-row has-alert bg-white hover:bg-slate-50' : 'business-data-row bg-white hover:bg-slate-50'}>
                        <td className="py-3 px-4 whitespace-nowrap">
                          {renderPriorityBadge(ap.alertLevel)}
                          <div className="text-[11px] text-slate-500 mt-0.5">{t(ap.agingBucket)}</div>
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                          <div>{ap.docNo}</div>
                          <div className="text-xs font-mono text-slate-500">NCC: {ap.vendorNo}</div>
                        </td>
                        <td className="py-3 px-4 font-semibold text-slate-800">
                          <div>{t(ap.supplierName)}</div>
                          <div className="text-xs text-slate-500">{ap.category}</div>
                          {isRed && (
                            <AlertAssignmentLine
                              alertRef={{ id: alertObj.id, type: 'payables', reference: ap.docNo }}
                              tasks={allDirectoryTasks}
                              accounts={accounts}
                              reminders={allReminders}
                              canRemind={canRemindBoss}
                              onRemind={() => remindWorkAlert(alertObj)}
                              compact={true}
                            />
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-slate-800">{t(ap.sku)}</div>
                          <div className="text-xs text-slate-500">{ap.poId}</div>
                        </td>
                        <td className="py-3 px-4 text-center whitespace-nowrap">
                          <div className="font-bold text-slate-800">{ap.dueDate}</div>
                          {ap.overdueDays > 0 && (
                            <span className="text-xs font-bold text-rose-600">{phrase('Quá hạn § ngày', ap.overdueDays)}</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-slate-700">{formatVnd(ap.allocatedPaid)}</td>
                        <td className={`py-3 px-4 text-right font-mono font-bold ${isRed ? 'text-rose-700' : 'text-slate-900'}`}>{formatVnd(ap.remaining)}</td>
                        <td className="py-3 px-4 text-center whitespace-nowrap">
                          <span className={`px-2.5 py-1 rounded-md text-xs font-semibold ${
                            status === AP_APPROVED
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-200 text-slate-800'
                          }`}>
                            {t(status)}
                          </span>
                        </td>
                        <td className="py-3 px-4 sticky-action"><div className="row-actions">{action && <button onClick={() => openWorkspace({ type: action.type, data: ap })} className="row-primary-button">{t(action.label)}</button>}{canManageApCrud && <button type="button" className="row-detail-button" onClick={() => openWorkspace({ type: 'EDIT_AP', debtType: 'payables', data: ap })}>{t("Sửa")}</button>}{canManageApCrud && Number(ap.allocatedPaid || 0) === 0 && <button type="button" className="row-detail-button" onClick={() => handleDeleteDebt('payables', ap)}>{t("Xóa")}</button>}<button className="row-detail-button" onClick={() => openWorkspace({ type: 'DEBT_DETAIL', debtType: 'payables', data: ap })}>{t("Chi tiết")}<ChevronRight size={15} /></button></div></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <ProgressivePaginationBar pagination={apPagination} itemUnit="khoản phải trả" />
          </section>
        )}
        </div>
        {['revenue', 'receivables', 'payables'].includes(activeSection) && <FinanceHistory entries={visibleFinanceHistory} />}
      </main>}
      </Suspense>
      {workspacePanel && can(currentUser, 'dashboard.read') && (
        <div className={`workspace-overlay ${isFullScreenPanel ? 'is-fullscreen' : ''}`}>
          <div
            role="dialog" aria-modal="true" aria-labelledby="workspace-title"
            className={`workspace-dialog ${isFullScreenPanel ? 'is-fullscreen' : ''}`}
          >
            <div className="workspace-header">
              <div className="workspace-header-main">
                <button
                  onClick={requestCloseWorkspace}
                  aria-label={t("Quay lại bảng")}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer flex items-center gap-1 text-xs font-semibold"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{t("Quay lại bảng")}</span>
                </button>
                <div className="workspace-title-block">
                  {workspacePanel.type === 'ITEM_DETAIL' && <p>{workspacePanel.data.poId} · {t(workspacePanel.data.vendorName)}</p>}
                  <h3 id="workspace-title" className="text-base sm:text-lg font-bold">
                    {workspacePanel.type === 'ITEM_DETAIL' && t(workspacePanel.data.vendorItemNo)}
                    {t(workspacePanel.type === 'ALLOCATE_AR' && 'Phân bổ tiền thu')}
                    {t(workspacePanel.type === 'CREATE_AR' && 'Thêm khoản công nợ phải thu')}
                    {t(workspacePanel.type === 'EDIT_AR' && 'Cập nhật công nợ phải thu')}
                    {t(workspacePanel.type === 'RECORD_REV' && 'Ghi nhận doanh thu')}
                    {t(workspacePanel.type === 'CREATE_AP' && 'Thêm khoản công nợ phải trả')}
                    {t(workspacePanel.type === 'EDIT_AP' && 'Cập nhật công nợ phải trả')}
                    {t(workspacePanel.type === 'SUBMIT_AP' && 'Lập đề nghị chi')}
                    {t(workspacePanel.type === 'SPLIT_AP' && 'Tách chứng từ phải trả')}
                    {t(workspacePanel.type === 'REVIEW_AP' && 'Xem xét đề nghị chi')}
                    {t(workspacePanel.type === 'PAY_AP' && 'Ghi nhận khoản đã chi')}
                    {workspacePanel.type === 'DEBT_DETAIL' && workspacePanel.data.docNo}
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsFullScreenPanel(!isFullScreenPanel)}
                  aria-label={t(isFullScreenPanel ? 'Thu gọn cửa sổ' : 'Mở toàn màn hình')}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  {isFullScreenPanel ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  <span>{t(isFullScreenPanel ? 'Thu gọn' : 'Toàn màn hình')}</span>
                </button>
                <button
                  onClick={requestCloseWorkspace}
                  aria-label={t("Đóng chi tiết")}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="workspace-body" onChangeCapture={event => { if (event.target.closest('form')) { setWorkspaceDirty(true); setWorkspaceError(''); } }}>
              {workspaceError && <div className="workspace-error" role="alert" tabIndex={-1}><AlertTriangle size={18} /><span>{t(workspaceError)}</span></div>}
              {workspacePanel.type === 'ITEM_DETAIL' && <ItemDetailPanel item={workspacePanel.data} reportDate={reportDate} canEdit={canUpdateProgress} canLowerAlerts={isExecutiveRole(currentRole)} financials={itemFinancialSummary(workspacePanel.data, { revenue: showRevenue ? revenueRecords : [], receivables: classifiedAr, payables: classifiedAp })} isSaving={isSavingWorkspace} onSubmit={handleUpdateItemProgress} onClose={requestCloseWorkspace} tasks={allDirectoryTasks} accounts={accounts} reminders={allReminders} onRemindAlert={canRemindBoss ? remindWorkAlert : undefined} />}
              {['ALLOCATE_AR', 'CREATE_AR', 'EDIT_AR', 'RECORD_REV', 'CREATE_AP', 'EDIT_AP', 'SPLIT_AP', 'SUBMIT_AP', 'REVIEW_AP', 'PAY_AP'].includes(workspacePanel.type) &&
                (!financeLoaded || (needsDebtRecord && !workspaceDebt) ? <p role="status">{t(dataError || (dataLoading || !financeLoaded
                  ? 'Đang tải dữ liệu…' : 'Chứng từ không còn trong dữ liệu hiện tại.'))}</p> :
                  <fieldset className="min-w-0" disabled={isSavingWorkspace || dataLoading || Boolean(dataError)} aria-busy={isSavingWorkspace || dataLoading}>
                {workspacePanel.type === 'ALLOCATE_AR' && <ReceiptWorkspace initialDebtId={workspacePanel.data?.id} finance={finance} onAction={handleFinanceAction} onClose={requestCloseWorkspace} />}
                {workspacePanel.type === 'CREATE_AR' && <ReceivableCrudForm mode="create" finance={finance} items={vendorItems} onAction={handleFinanceAction} onClose={requestCloseWorkspace} />}
                {workspacePanel.type === 'EDIT_AR' && <ReceivableCrudForm mode="edit" row={workspaceDebt} finance={finance} items={vendorItems} onAction={handleFinanceAction} onClose={requestCloseWorkspace} />}
                {workspacePanel.type === 'RECORD_REV' && <InvoiceForm finance={finance} items={vendorItems} onAction={handleFinanceAction} onClose={requestCloseWorkspace} />}
                {workspacePanel.type === 'CREATE_AP' && <PayableCrudForm mode="create" items={vendorItems} onAction={handleFinanceAction} onClose={requestCloseWorkspace} />}
                {workspacePanel.type === 'EDIT_AP' && <PayableCrudForm mode="edit" row={workspaceDebt} items={vendorItems} onAction={handleFinanceAction} onClose={requestCloseWorkspace} />}
                {workspacePanel.type === 'SPLIT_AP' && <SplitPayableForm row={workspaceDebt} items={vendorItems} onAction={handleFinanceAction} onClose={requestCloseWorkspace} />}
                {['SUBMIT_AP', 'REVIEW_AP', 'PAY_AP'].includes(workspacePanel.type) && <PayableForm actorId={currentUser.id} actorRole={currentRole} type={workspacePanel.type} row={workspaceDebt} onAction={handleFinanceAction} onClose={requestCloseWorkspace} />}
              </fieldset>)}
              {workspacePanel.type === 'DEBT_DETAIL' && <DebtDetailPanel row={classifyDebt(workspaceDebt ?? workspacePanel.data, reportDate)} debtType={workspacePanel.debtType} role={currentRole} canSplit={showOrders} history={visibleFinanceHistory} onOpen={openWorkspace} onClose={requestCloseWorkspace} onDelete={handleDeleteDebt} tasks={allDirectoryTasks} accounts={accounts} reminders={allReminders} onRemindAlert={canRemindBoss ? remindWorkAlert : undefined} />}
            </div>
          </div>
          {showDiscardDialog && <div className="discard-overlay"><section role="alertdialog" aria-modal="true" aria-labelledby="discard-title" className="discard-dialog"><h3 id="discard-title">{t("Bạn chưa lưu thay đổi")}</h3><p>{t("Giữ cửa sổ này để tiếp tục chỉnh sửa hoặc bỏ phần chưa lưu.")}</p><div><button className="primary" onClick={() => { setShowDiscardDialog(false); document.querySelector('.workspace-dialog input:not([type=hidden]), .workspace-dialog textarea')?.focus(); }}>{t("Tiếp tục chỉnh sửa")}</button><button onClick={() => { setShowDiscardDialog(false); setWorkspaceDirty(false); setWorkspacePanel(null); }}>{t("Bỏ thay đổi")}</button></div></section></div>}
        </div>
      )}
    </div>
  );
}
